
from tkinter import *
from tkinter import filedialog
from tkinter.filedialog import askopenfilename
from tkinter.messagebox import showerror
from email.parser import BytesParser, Parser
from email.policy import default
from email.message import EmailMessage
from tkinter.ttk import Combobox
import json

import vectors as vectors
from bs4 import BeautifulSoup
from os import walk, terminal_size
import os
import xml.etree.cElementTree as ET
import html.parser
import pre_process as pr
import pathlib
import w2v_model as wv
import h_cluster as cl
import elbow as el
import k_means as km

class Interface(Frame):
    folder_path=""
    """Notre fenêtre principale.
    Tous les widgets sont stockés comme attributs de cette fenêtre."""

    def __init__(self, fenetre, **kwargs):
        self.CheckVar1 = BooleanVar()
        self.CheckVar1.set(False)
        self.CheckVar2 = BooleanVar()
        self.CheckVar2.set(False)
        self.CheckVar3 = BooleanVar()
        self.CheckVar3.set(False)
        self.CheckVar4 = BooleanVar()
        self.CheckVar4.set(False)
        self.__name = StringVar()
        self.__namem =StringVar()
        self.v = IntVar()
        self.liste = ["single", "complete", "average", "centroid", "weighted", "median", "ward"]
        self.liste1 = ["euclidean", "cosine"]
        self.liste2 = [0, 1, 2]
        Frame.__init__(self, fenetre, **kwargs)
        self.pack(fill=BOTH, expand=True)
        self.message = Label(self, text="Welcome")
        self.message.grid(row=0,  columnspan=10)
        #self.message.pack(side="top", fill=X)

        self.bouton_selectionner = Button(self, text="Choose directory", fg="red",  command=self.opendir)
        self.bouton_selectionner.grid(row= 1, column=0, columnspan=2)
        #self.bouton_selectionner.pack(side="left")

        self.bouton_parser = Button(self, text="Parser", state='disabled', command=self.parser)
        self.bouton_parser.grid(row= 1, column=3)
        #self.bouton_parser.pack(side="left")
        self.messagee = Label(self, fg="red", text=" ")
        self.messagee.grid(row=1, column=4, columnspan=3, rowspan=2)

        self.message1 = Label(self, text="Pretreatment before classification")
        self.message1.grid(row=2, column=0,  columnspan=3, rowspan=2 )
        self.bouton_selectionner1 = Button(self, text="Choose file", fg="red", command=self.openfile)
        self.bouton_selectionner1.grid(row=5, column=0, columnspan=2)
        self.bouton_Preprocess = Button(self, text="Pre-process", state='disabled', command=self.precessesing)
        self.bouton_Preprocess.grid(row= 5, column=3)
        self.ckeckOne = Checkbutton(self, text="Treetagger", variable=self.CheckVar1)
        self.ckeckOne.grid(row=5, column=4)
        self.ckeckTwo = Checkbutton(self, text="Lemmalisation", variable=self.CheckVar2)
        self.ckeckTwo.grid(row=5, column=5)
        self.messagew = Label(self, fg="red", text=" ")
        self.messagew.grid(row=5, column=6)



        self.message2 = Label(self, text="Choose algorithm")
        self.message2.grid(row=6, column=0 )
        self.bouton_selectionner2 = Button(self, text="Choose file", fg="red", command=self.openfile_1)
        self.bouton_selectionner2.grid(row=7, column=0, columnspan=2)
        self.bouton_wordvec = Button(self, text="Word2vec",state='disabled', command=self.word2vec)
        self.bouton_wordvec.grid(row=7, column=3)
        self.messagewor = Label(self, fg="red", text=" ")
        self.messagewor.grid(row=7, column=5)
        self.bouton_elbow = Button(self, text="Elbow", state='disabled', command=self.elbow)
        self.bouton_elbow.grid(row=8, column=3)
        self.comboExample3 = Combobox(self,
                                      values=self.liste2)
        self.comboExample3.grid(row=8, column=4, columnspan=1)
        self.messagel = Label(self, fg="red", text=" ")
        self.messagel.grid(row=8, column=5)
        self.bouton_cluster = Button(self, text="H-cluster", state='disabled', command=self.hcluster)
        self.bouton_cluster.grid(row=9, column=3)
        self.message3 = Label(self, text="method")
        self.message3.grid(row=9, column=4)
        self.comboExample = Combobox(self,
                                     values=self.liste)
        self.comboExample.grid(row=9, column=5, columnspan=1)
        self.message4 = Label(self, text="metric")
        self.message4.grid(row=9, column=6)
        self.comboExample1 = Combobox(self, values=self.liste1)
        self.comboExample1.grid(row=9, column=7, columnspan=1)
        self.messagehclus = Label(self, fg="red", text=" ")
        self.messagehclus.grid(row=9, column=8)
        self.bouton_means = Button(self, text="K-means", state='disabled', command=self.kmeans)
        self.bouton_means.grid(row=10, column=3)
        self.message5 = Label(self, text="max clusters (int)")
        self.message5.grid(row=10, column=4)
        self.e = Entry(self, textvariable=self.v)
        self.e.grid(row=10, column=5)
        self.v.set("int value")
        self.messagemeans = Label(self, fg="red", text=" ")
        self.messagemeans.grid(row=10, column=6)

        '''self.message3 = Label(self, text="Mails comparison")
        self.message3.grid(row=11, column=0)
        self.bouton_selectionner3 = Button(self, text="Choose mail to compare it", fg="red", command=self.openfile_2)
        self.bouton_selectionner3.grid(row=11, column=0, columnspan=2)
        self.bouton_selectionner4 = Button(self, text="Choose files directory for the comparison", fg="red", command=self.opendir_2)
        self.bouton_selectionner4.grid(row=11, column=2, columnspan=3)
        self.bouton_tfidf = Button(self, text="TF-IDF comparison", command=self.tf_idf)
        self.bouton_tfidf.grid(row=11, column=5)
        self.messagetfidf = Label(self, fg="red", text=" ")
        self.messagetfidf.grid(row=11, column=6)'''
        self.b2 = Button(self, text='Quit', command=self.quit)
        self.b2.grid(row=25, column=5)

    def precessesing (self):
        tretag = False
        lem = False
        if self.CheckVar1.get() == TRUE:
            tretag = True
        if self.CheckVar2.get() == TRUE:
            lem = True

        pr.process(pathlib.Path(self.folder_path), tretag, ["NOM", "VER", "ADJ", "NAM"], lem)
        self.messagew.configure(text="preprocess finished successfully")

    def tf_idf(self):
        os.system("python WORD_CONTEXT/clustering/newk-means.py -p" + self.opendir_2() + " -f" + self.openfile_2()
                  )
        self.messagel.configure(text="comparison finished successfully")


    def elbow(self):
        os.system("python WORD_CONTEXT/word2vec/elbow.py -p" + self.folder_path + " -m" + self.comboExample3.get()
                      )
        self.messagel.configure(text="elbow finished successfully")


    def word2vec(self):
        wv.build(pathlib.Path(self.folder_path), 10, 1, 7, json.loads(open(str(pathlib.Path(__file__).absolute().parent
                                                                               .parent.parent / pathlib.Path
        ('resources/stopwords.json'))).read()))

        self.messagewor.configure(text="word2vec finished successfully")

    def hcluster(self):
        methode = self.comboExample.get()
        metrice = self.comboExample1.get()
        os.system("python WORD_CONTEXT/word2vec/h_cluster.py -p " + self.folder_path + " -m " + methode + " -e" +
                  metrice)
        self.messagehclus.configure(text="h-cluster finished successfully")

    def kmeans (self):
        try:
            val = int(self.v.get())
            #km.kmeans_clustering(pathlib.Path(self.folder_path), int(self.v.get()))
            os.system("python WORD_CONTEXT/word2vec/k_means.py -p" + self.folder_path + " -m " + str(self.v.get()))

            self.messagemeans.configure(text="k-means finished successfully")
        except TclError:
            self.messagemeans.configure(text="error")

    def opendir(self):
        # Allow user to select a directory and store it in global var
        # called folder_path
        import os
        os.system('ls -l')

        filename = filedialog.askdirectory()
        self.folder_path = filename
        self.bouton_parser.config(state="normal")

    def opendir_2(self):
        # Allow user to select a directory and store it in global var
        # called folder_path
        import os
        os.system('ls -l')

        filename = filedialog.askdirectory()
        self.folder_path = filename
        self.bouton_tfidf.config(state="normal")
        return filename


    def openfile(self):
        # Allow user to select a directory and store it in global var
        # called folder_path
        filename = filedialog.askopenfilename()
        self.folder_path = filename
        self.bouton_Preprocess.config(state="normal")

    def openfile_1(self):
        # Allow user to select a directory and store it in global var
        # called folder_path

        filename = filedialog.askopenfilename()
        self.folder_path = filename
        self.bouton_wordvec.config(state="normal")
        self.bouton_means.config(state="normal")
        self.bouton_cluster.config(state="normal")
        self.bouton_elbow.config(state="normal")

    def openfile_2(self):
        # Allow user to select a directory and store it in global var
        # called folder_path
        filename = filedialog.askopenfilename()
        self.folder_path = filename
        return filename



    def parser(self):
        print(self.folder_path)
        print("debut parssage")
        self.message.configure(text="Parsage en cours  ")
        fp = open("result.txt", 'w')
        for dirpath,_,filenames in os.walk(self.folder_path):
            for f in filenames:
                filename= os.path.abspath(os.path.join(dirpath, f))
                with open(filename, 'rb') as file:
                    headers = BytesParser(policy=default).parse(file)
                    for part in headers.walk():
                        ctype = part.get_content_type()
                        cdispo = str(part.get('Content-Disposition'))
                        if ctype == 'text/plain' or ctype == 'text/html':
                            body = part.get_payload(decode=True)  # decode
                            soup = BeautifulSoup(body, "html.parser")
                            contenue = soup.get_text()
                            fp.write(contenue)
        fp.close()
        self.messagee.configure(text="finish parsing  ")
        print("fin du parsage")
        self.comboExample.config(state="normal")


if __name__ == "__main__":
    fenetre = Tk()
    fenetre.title("Parseur and classifieur")
    fenetre.minsize(width=100, height=100)
    fenetre.geometry('1000x520+0+0')
    fenetre.configure(background="AntiqueWhite1")
    interface = Interface(fenetre)
    #interface.configure(background="AntiqueWhite1")
    interface.mainloop()
