# coding: utf-8

import argparse
import codecs
import collections
# A script to clean data
import getopt
import json
import os
import pathlib
import re
import sys
import time

import gensim
import pandas as pd;

import langid
import matplotlib.pyplot as plt
import nltk
import unicodedata
from pathlib import Path

from sklearn.cluster import KMeans, MiniBatchKMeans
from wordcloud import WordCloud
from str2bool import str2bool
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import TfidfVectorizer

nltk.download('punkt')
nltk.download('stopwords')




def vectors(dir_name, file):
    vectorizer = CountVectorizer()
    transformer = TfidfTransformer()
    vector = TfidfVectorizer()
    files = os.listdir(dir_name)
    i = 1
    core = ' '
    with open(file, 'rb') as referent:
        referentefile = referent.read()
    for fname in files:
        fp = open("matrice" + str(i) + ".txt", 'w')
        filename = os.path.abspath(os.path.join(dir_name, fname))
        with open(filename, 'rb') as file:
            #matrice creation for each files
            trainVectorizerArray = vectorizer.fit_transform(file)
            transformer.fit(trainVectorizerArray)
            tfidf = transformer.transform(trainVectorizerArray)
            fp.write(str(tfidf))
            i = i + 1
            fp.close()
    #comparaison between the documents
    fp = open("Resultat comparaison.txt", 'w')
    resultat = {}
    for fname in files:
        filename = os.path.abspath(os.path.join(dir_name, fname))
        fp.write(str(filename) + "\n")
        print(filename)
        with open(filename, 'rb') as file:
            vecs = vector.fit_transform([referentefile, file.read()])
            #similarity
            corr_matrix = ((vecs * vecs.T).A)
            resultat[ str(filename) ] = str(round(corr_matrix[0,1]*100))+"%"
    print(resultat)
    fp.write("Pourcentage de similiraté avec chaque fichier :" + "\n")
    fp.write(str(resultat))
    fp.close()




if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-p", "--dir", required=True, help="path of the files")
    ap.add_argument("-f", "--file", required=True, help="referent file")

    args = vars(ap.parse_args())
    vectors(args["dir"], args["file"])
